# -*- coding: utf-8 -*-

from . import project_template
